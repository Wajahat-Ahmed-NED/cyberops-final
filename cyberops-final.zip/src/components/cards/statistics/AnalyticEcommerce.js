import PropTypes from 'prop-types';

// material-ui
import { Box, Chip, Grid, Stack, Typography, Button } from '@mui/material';

// project import
import MainCard from 'components/MainCard';

// assets
import { RiseOutlined, FallOutlined } from '@ant-design/icons';

// ==============================|| STATISTICS - ECOMMERCE CARD  ||============================== //

const AnalyticEcommerce = ({ color, title, count, percentage, isLoss, extra, fontColor }) => (
    <>
        <MainCard contentSX={{ p: 2.25 }}>
            <Stack spacing={0.5}>
                <Typography variant="h6" color="textSuccess" style={{ color: 'black ' }}>
                    {title}
                </Typography>
                <Grid container alignItems="center">
                    <Grid item>
                        <Typography variant="h4" style={{ color: `${fontColor}`, fontWeight: 'bold' }} type="number">
                            {count ? count : 0}
                        </Typography>
                    </Grid>
                    {percentage && (
                        <Grid item>
                            <Chip
                                variant="combined"
                                color={color}
                                icon={
                                    <>
                                        {!isLoss && <RiseOutlined style={{ fontSize: '0.75rem', color: 'inherit' }} />}
                                        {isLoss && <FallOutlined style={{ fontSize: '0.75rem', color: 'inherit' }} />}
                                    </>
                                }
                                label={`${percentage}%`}
                                sx={{ ml: 1.25, pl: 1 }}
                                size="small"
                            />
                        </Grid>
                    )}
                </Grid>
            </Stack>
            {/* <Box sx={{ pt: 2.25 }}>
            <Typography variant="caption" color="textSecondary">
                <Typography component="span" variant="caption" sx={{ color: `${color || 'primary'}.main` }}>
                    {extra}
                </Typography>{' '}
                created today
            </Typography>
        </Box> */}
        </MainCard>
    </>
);

AnalyticEcommerce.propTypes = {
    color: PropTypes.string,
    title: PropTypes.string,
    count: PropTypes.number,
    percentage: PropTypes.number,
    isLoss: PropTypes.bool,
    extra: PropTypes.oneOfType([PropTypes.node, PropTypes.string])
};

AnalyticEcommerce.defaultProps = {
    color: 'primary'
};

export default AnalyticEcommerce;
